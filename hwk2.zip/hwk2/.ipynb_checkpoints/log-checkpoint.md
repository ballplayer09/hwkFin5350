David and Isaac log file, 3 pm on 10/7

David 3:00 - 3:20
Brainstorm ideas to solve the nugget problem

Isaac 3:20 - 3:40
attempt logic to determine if a given number is a possible combination of the nugget box sizes

David 3:40 - 4:10
attempt logic to create a list of all possible nugget combinations
move on to problem two. Created logic to generate guesses from the computer and evaluate if the answer is correct

Isaac 4:10 - 4:25
fixed bug in the logic that was preventing the computer to get to the right answer


Programming Log file 10/12 3:06 PM

Isaac: 3:05-3:26
Discussed plans to proceed, building main function of nuggets problem

David: 3:27 - 3:54
Finished nuggets problem, moved onto bond pricing. David completed one present value function, began the function using cashflows and passed to Isaac.

Isaac: 3:58 - 4:30
Finished bond pricing with cashflows and checked our answers. Then coded Problem 4 using our experience with problems 2 & 3, went much smoother than the first few. Have some troubleshooting 

David and Isaac log file, 3 pm on 10/28

Isaac: 3 - 3:15
Completed addendum problems 1 and 2

David: 3:15 - 3:40
Completed addendum problems 3 through 5

Isaac: 3:40 - 4:15
Completed the remaining problems but found that our yield to maturity function results were not matching the numpy_financial irr function