import numpy as np
print(f"The value of Pi to 8 decimal places is {np.pi:0.8}")