Pair programming -- David and Isaac -- 9/15 -- 1:30 to 2:00 pm

Driver times
David 15 minutes
Isaac 15 minutes

Completed the homework assignment. We had some issues running python files from command line. We created the files by creating new notebooks and then changing the file extension to .py. However, when we created text files and changed the file extension the issue was resolved.